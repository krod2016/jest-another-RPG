function randomNumber() {
  return Math.floor(Math.random() * 10) + 1;
}

module.exports = randomNumber;
